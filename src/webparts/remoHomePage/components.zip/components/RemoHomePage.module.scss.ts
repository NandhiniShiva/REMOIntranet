/* tslint:disable */
require("./RemoHomePage.module.css");
const styles = {
  remoHomePage: 'remoHomePage_b6f7523d',
  teams: 'teams_b6f7523d',
  welcome: 'welcome_b6f7523d',
  welcomeImage: 'welcomeImage_b6f7523d',
  links: 'links_b6f7523d',
  organizatinChart: 'organizatinChart_b6f7523d',
  container: 'container_b6f7523d',
  row: 'row_b6f7523d',
  column: 'column_b6f7523d',
  'ms-Grid': 'ms-Grid_b6f7523d',
  title: 'title_b6f7523d',
  subTitle: 'subTitle_b6f7523d',
  description: 'description_b6f7523d',
  button: 'button_b6f7523d',
  label: 'label_b6f7523d',
  ceoMessageReadMore: 'ceoMessageReadMore_b6f7523d'
};

export default styles;
/* tslint:enable */